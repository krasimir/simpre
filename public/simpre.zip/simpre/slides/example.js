function doThePresentation() {
  return 'Sure!';
}
console.log(doThePresentation());